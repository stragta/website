# Entradas del demo Pluspetrol

Este paquete contiene cinco fichas de noticias y cinco fichas documentales en Markdown, resumidas y enlazadas a fuentes oficiales. No son copias completas de los informes o artículos. No incluye PDF originales.

Descomprime el paquete. En la raíz de tu proyecto:

- Copia los cinco archivos de noticias/ a entrada/noticias/.
- Copia los cinco archivos de documentos/ a entrada/documentos/.
- No añadas la carpeta entradas_demo_pluspetrol como una subcarpeta de entrada.

Comprueba que existan exactamente cinco noticias y cinco fichas documentales antes de iniciar la primera ejecución. Mantén sus nombres, metadatos, enlaces y advertencias. Estas fichas conservan el contexto del demo y no constituyen una actualización automática de sus fuentes.

Fuentes documentales: IEA — Energy and AI; IEA — Key Questions on Energy and AI; USGS — Mineral Commodity Summaries 2025; Lawrence Berkeley National Laboratory/DOE — Data Center Energy Usage; ARCONEL — Estadística del Sector Eléctrico Ecuatoriano.

Guía de carga: https://www.stragta.com/formacion/pluspetrol/construccion-desde-cero.html#ejecucion

Para un ejercicio opcional posterior, puedes añadir un PDF oficial nuevo a entrada/documentos/. El motor detecta archivos y calcula sus huellas; la interpretación del PDF depende de Work o Codex. El motor no incluye un extractor PDF propio.
