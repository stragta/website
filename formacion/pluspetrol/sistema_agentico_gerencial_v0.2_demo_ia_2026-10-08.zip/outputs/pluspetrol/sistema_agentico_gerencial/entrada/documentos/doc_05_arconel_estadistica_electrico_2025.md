# Estadística Anual y Multianual del Sector Eléctrico Ecuatoriano 2025

- **tipo_documento:** estadística sectorial oficial
- **autor_o_institucion:** Agencia de Regulación y Control de Electricidad (ARCONEL)
- **fecha_documento:** 2026-03
- **fuente:** ARCONEL
- **url:** https://arconel.gob.ec/wp-content/uploads/downloads/2026/03/Estadistica2025.pdf
- **relevancia_demo:** alta
- **temas:** Ecuador, electricidad, generación, transmisión, distribución, cobertura, planificación

## Resumen

Publicación oficial que reúne indicadores de generación, transmisión, distribución, movilidad eléctrica, cobertura y evolución del sistema eléctrico ecuatoriano. Es la fuente de contexto nacional para no hablar de Ecuador únicamente desde hipótesis internacionales.

## Datos destacados

- Ecuador superó los **5,8 millones de consumidores** del servicio eléctrico.
- La cobertura nacional reportada fue aproximadamente **97,81 %**.
- La producción anual total de generación eléctrica reportada fue de **38.212 GWh**.
- El documento incluye análisis territoriales y el Atlas Eléctrico, útiles para revisar infraestructura, redes y zonas prioritarias.

## Lectura para el taller

Estas cifras describen el sistema eléctrico nacional, no la disponibilidad automática de capacidad para un centro de datos. Para una evaluación de infraestructura habría que revisar potencia firme, transmisión, subestaciones, agua, permisos, conectividad y continuidad.

## Preguntas para el Investigador

1. ¿Qué dato es nacional y cuál sería necesario desagregar por región?
2. ¿Qué diferencia existe entre energía anual (GWh), potencia (MW) y cobertura?
3. ¿Qué fuentes oficiales adicionales deberían consultarse antes de comparar Sierra, Costa, Amazonía y Galápagos?
