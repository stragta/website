# Mineral Commodity Summaries 2025 · galio y tierras raras

- **tipo_documento:** compendio estadístico de minerales
- **autor_o_institucion:** U.S. Geological Survey (USGS)
- **fecha_documento:** 2025-01
- **fuente:** USGS, Mineral Commodity Summaries 2025
- **url:** https://pubs.usgs.gov/publication/mcs2025
- **relevancia_demo:** alta
- **temas:** galio, tierras raras, imanes permanentes, semiconductores, minerales críticos, cadena de suministro

## Resumen

El compendio del USGS reúne producción, comercio, reservas, reciclaje y riesgos de suministro de minerales estratégicos. Para la cadena de IA son especialmente útiles las fichas de galio, tierras raras y silicio: no representan lo mismo dentro del sistema, pero muestran cómo la concentración geográfica puede generar dependencia.

## Datos clave para el taller

- China representó aproximadamente el **99 % de la producción primaria mundial de galio de baja pureza** en 2024.
- La producción mundial de galio refinado de alta pureza se estimó en unas **320.000 kg** en 2024.
- El galio es un insumo para semiconductores compuestos como GaN y GaAs; la conexión directa con cada acelerador de IA depende del diseño del sistema, pero sí afecta electrónica de potencia, radiofrecuencia y conversión eléctrica.
- China fue el principal productor de 30 de 44 minerales críticos con estimaciones confiables en el compendio; 14 de ellos son lantánidos incluidos en tierras raras.
- Para Estados Unidos, el USGS reportó 45.000 toneladas de óxidos equivalentes de tierras raras en concentrados mineros en 2024 y una fuerte dependencia de importaciones de compuestos y metales.

## Conceptos que deben distinguirse

- **Oblea:** disco de silicio u otro semiconductor sobre el que se fabrican múltiples chips.
- **Galio:** elemento usado en materiales semiconductores compuestos; no sustituye al silicio en toda la cadena.
- **Imán permanente de tierras raras:** material magnetizado que conserva su magnetismo; los imanes NdFeB se usan en motores, actuadores y sistemas de potencia.
- **Refinado:** etapa que eleva la pureza y convierte el material extraído en un insumo industrial utilizable.

## Preguntas para el Investigador

1. ¿Qué parte de la cadena está concentrada en minería, refinado, obleas, empaquetado o fabricación?
2. ¿Qué afirmaciones son datos USGS y cuáles son inferencias sobre IA?
3. ¿Qué minerales aparecen como críticos para electrónica de potencia aunque no estén dentro del chip de cómputo?

## Nota de uso

No debe decirse que las tierras raras “son el chip”. Son materiales de una cadena más amplia: motores, imanes, electrónica de potencia, equipos y otras infraestructuras.
