# Key Questions on Energy and AI

- **tipo_documento:** actualización de análisis
- **autor_o_institucion:** International Energy Agency (IEA)
- **fecha_documento:** 2026
- **fuente:** IEA
- **url:** https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary
- **relevancia_demo:** alta
- **temas:** centros de datos, demanda eléctrica, agentes, eficiencia, chips, memoria HBM, energía

## Resumen

Actualización de la IEA sobre la evolución de la IA y su infraestructura física. El documento revisa el crecimiento de centros de datos, la eficiencia por tarea, el aumento de usos intensivos y los cuellos de botella en electricidad, chips y redes.

## Datos clave para el taller

- El consumo eléctrico de los centros de datos creció **17 % en 2025**; los centros orientados a IA crecieron alrededor de **50 %**.
- La IEA proyecta que el consumo de centros de datos pase aproximadamente de **485 TWh en 2025 a 950 TWh en 2030**.
- El consumo de los centros enfocados en IA podría triplicarse entre 2025 y 2030.
- La energía por tarea de IA ha disminuido con rapidez, pero los usos de vídeo, razonamiento y agentes pueden consumir cientos o miles de veces más que una tarea simple de texto.
- La densidad de potencia de los servidores de IA aumentó fuertemente y crea presión sobre transformadores, electrónica de potencia, memoria de alto ancho de banda y conexiones a red.

## Lectura para el taller

Este documento conecta directamente con la explicación de que una respuesta breve y una tarea agentica prolongada no tienen necesariamente el mismo perfil de energía. También permite introducir la diferencia entre eficiencia por tarea y consumo total del sistema.

## Preguntas para el Investigador

1. ¿Qué tareas de nuestro demo son de texto simple y cuáles implican varios pasos?
2. ¿Qué cuellos de botella son de energía, cuáles de chips y cuáles de capital o permisos?
3. ¿Cómo debería explicarse la incertidumbre al público no técnico?
