# United States Data Center Energy Usage Report · 2025 Update

- **tipo_documento:** informe técnico
- **autor_o_institucion:** Lawrence Berkeley National Laboratory / U.S. Department of Energy
- **fecha_documento:** 2025-12
- **fuente:** U.S. Department of Energy
- **url:** https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update
- **relevancia_demo:** alta
- **temas:** centros de datos, electricidad, GPU, ASIC, PUE, refrigeración, demanda, incertidumbre

## Resumen

Actualización técnica del modelo de consumo eléctrico de centros de datos en Estados Unidos. El estudio usa datos de equipos instalados, envíos de servidores, potencia por dispositivo, utilización, infraestructura y simulaciones de refrigeración.

## Datos clave para el taller

- El consumo eléctrico estimado de los centros de datos estadounidenses fue de **192 TWh en 2024**, equivalente al **4,7 %** del consumo eléctrico del país.
- El escenario de referencia proyecta **649 TWh en 2030**, alrededor del **11,8 %** de la electricidad estadounidense proyectada para ese año.
- Los escenarios de sensibilidad sitúan 2030 entre **521 y 843 TWh**, o aproximadamente 9,5 %–15,3 % del consumo eléctrico estadounidense.
- En el escenario de referencia, los servidores de IA representan el **55 % del consumo total de los centros de datos en 2030**.
- El informe subraya que la eficiencia por operación no elimina necesariamente el crecimiento del consumo total cuando aumenta la escala de uso.
- La metodología incorpora PUE, una métrica que relaciona la energía total de la instalación con la energía de los equipos informáticos.

## Lectura para el taller

Es una buena fuente para explicar por qué no existe una cifra universal de “energía por consulta”: cambian el modelo, el hardware, la utilización, el centro de datos, la refrigeración y el mix eléctrico.

## Preguntas para el Investigador

1. ¿Qué diferencias hay entre una medición histórica y un escenario de referencia?
2. ¿Qué variables explican el rango de incertidumbre?
3. ¿Qué información sería necesaria para estimar una actividad local sin inventar precisión?
