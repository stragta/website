# Energy and AI

- **tipo_documento:** informe analítico
- **autor_o_institucion:** International Energy Agency (IEA)
- **fecha_documento:** 2025-04-10
- **fuente:** IEA
- **url:** https://www.iea.org/reports/energy-and-ai
- **relevancia_demo:** alta
- **temas:** energía, inteligencia artificial, centros de datos, geopolítica, electricidad

## Resumen

Informe global de la IEA sobre la relación entre inteligencia artificial, centros de datos y sistemas energéticos. Combina un modelo global, datos regionales y consultas con gobiernos, empresas tecnológicas y expertos del sector energético.

## Datos clave para el taller

- Los centros de datos consumieron aproximadamente **415 TWh** en 2024, cerca del **1,5 % de la electricidad mundial**.
- En el escenario base de la IEA, el consumo eléctrico de los centros de datos supera **945 TWh en 2030** y llega a alrededor de **1.200 TWh en 2035**.
- En 2024, Estados Unidos concentró aproximadamente el 45 % del consumo eléctrico mundial de centros de datos; China, 25 %; y Europa, 15 %.
- Un centro de datos enfocado en IA puede consumir tanta electricidad como una fábrica intensiva en energía. Los centros más grandes en construcción pueden multiplicar varias veces esa escala.
- La demanda adicional se cubriría con una combinación de renovables, gas, nuclear y red eléctrica; la composición varía por región.

## Lectura para Ecuador

El informe no evalúa a Ecuador como destino específico. Sirve como marco para preguntar por potencia firme, conexión a red, transmisión, agua, regulación, clima, fibra y resiliencia antes de hablar de centros de datos.

## Preguntas para el Investigador

1. ¿Qué parte de las cifras es observación histórica y qué parte es proyección?
2. ¿Qué supuestos del escenario base podrían cambiar?
3. ¿Qué indicadores deberíamos buscar en Ecuador para comparar regiones?

## Nota de uso

Las proyecciones no son una promesa de inversión ni un pronóstico cierto. Deben presentarse junto con sus supuestos y rangos de incertidumbre.
