# El programa CHIPS apoya una estrategia estadounidense de mina a imán

- **tipo_registro:** noticia institucional / política industrial
- **fecha_publicacion:** 2026-06-03
- **fecha_consulta:** 2026-10-08
- **fuente:** National Institute of Standards and Technology (NIST), U.S. Department of Commerce
- **url:** https://www.nist.gov/news-events/news/2026/06/department-commerces-chips-program-finalizes-definitive-agreement-usa-rare
- **relevancia:** alta
- **temas:** minerales críticos, tierras raras, galio, imanes NdFeB, semiconductores, geopolítica

## Resumen

El Departamento de Comercio de Estados Unidos anunció un acuerdo de hasta USD 1.6 mil millones con USA Rare Earth: hasta USD 277 millones en incentivos y un préstamo de hasta USD 1.3 mil millones. El proyecto busca integrar minería y procesamiento con producción de aleaciones y de imanes de neodimio-hierro-boro (NdFeB), con una capacidad anunciada de hasta 10.000 toneladas anuales de metales y aleaciones y 10.000 toneladas anuales de imanes.

El comunicado enumera minerales estratégicos como disprosio, holmio, lutecio, galio, gadolinio, terbio, itrio, erbio, iterbio, hafnio y circonio.

## Por qué importa

Es un ejemplo actual de cómo la competencia por IA y electrónica se extiende desde los chips hacia minerales, refinado, aleaciones, imanes, energía y política industrial.

## Pregunta sugerida

¿Qué parte de una estrategia “mine-to-magnet” sería minería, cuál refinado y cuál manufactura avanzada?
