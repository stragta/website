# Microsoft reporta avances en eficiencia hídrica para centros de datos de IA

- **tipo_registro:** noticia corporativa / tecnología de centros de datos
- **fecha_publicacion:** 2026-06-24
- **fecha_consulta:** 2026-10-08
- **fuente:** Microsoft Official Blog
- **url:** https://blogs.microsoft.com/blog/2026/06/24/inside-microsofts-two-decade-push-to-cut-water-intensity-while-scaling-for-growth/
- **relevancia:** media
- **temas:** agua, centros de datos, refrigeración líquida, WUE, sostenibilidad, IA

## Resumen

Microsoft informó que su promedio de Water Usage Effectiveness (WUE) disminuyó de 2,3 L/kWh a 0,27 L/kWh en 2025, según su propia metodología. También describió diseños de refrigeración directa al chip en circuito cerrado que evitan la evaporación de agua durante la operación y señaló que cerca del 90 % de su flota propia de 2025 opera con sistemas de bajo o cero consumo de agua para refrigeración.

## Por qué importa

La noticia sirve para explicar que “la IA consume agua” no es una cifra fija: depende del diseño del centro, clima, sistema de refrigeración, fuente de agua y métrica usada. La reducción de agua en el centro no elimina otros consumos directos o indirectos.

## Advertencia

Es información corporativa de Microsoft. Sus cifras no representan automáticamente a todos los centros de datos ni deben generalizarse sin metodología comparable.
