# La IEA actualiza el panorama energético de la IA

- **tipo_registro:** noticia / actualización de informe
- **fecha_publicacion:** 2026
- **fecha_consulta:** 2026-10-08
- **fuente:** International Energy Agency (IEA)
- **url:** https://www.iea.org/reports/key-questions-on-energy-and-ai/executive-summary
- **relevancia:** alta
- **temas:** centros de datos, electricidad, IA agentica, chips, infraestructura

## Resumen

La actualización de la IEA señala que la electricidad de los centros de datos creció 17 % en 2025 y que los centros enfocados en IA crecieron aún más rápido. El análisis estima que el consumo mundial de centros de datos puede pasar de 485 TWh en 2025 a 950 TWh en 2030, mientras las cargas de IA se triplican.

La IEA también destaca que la eficiencia por tarea mejora, pero que vídeo, razonamiento y tareas agenticas pueden consumir mucho más que una consulta simple. El crecimiento está limitado por redes, transformadores, chips, memoria HBM, capital y permisos.

## Por qué importa

Conecta la eficiencia de cada tarea con el consumo total del ecosistema y permite explicar que los agentes no son solo una interfaz: pueden ejecutar cadenas de pasos y aumentar la carga computacional.

## Pregunta sugerida

¿Qué deberíamos medir en nuestro propio demo: número de tareas, pasos, tiempo de ejecución, modelo utilizado o energía estimada?
