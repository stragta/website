# Iniciar el proyecto en Codex · ruta rápida

Si el taller tiene tiempo suficiente para construir la arquitectura en vivo, use `GUIA_CONSTRUCCION_DESDE_CERO.md`. Este archivo describe la alternativa preparada para llegar directamente al demo.

## Preparación

1. Descomprima la carpeta completa en su computador.
2. Abra `config/perfil.json` y complete sus datos e intereses. También puede pedirle a Codex que le haga las preguntas y complete el archivo.
3. Coloque fuentes de noticias en `entrada/noticias`.
4. Coloque los documentos que quiera catalogar en `entrada/documentos`.

## Crear el proyecto

1. Abra la aplicación de escritorio de ChatGPT.
2. Entre en Codex.
3. Abra esta carpeta como proyecto local.
4. Abra un chat nuevo dentro del proyecto.

Codex leerá automáticamente `AGENTS.md`, que contiene las reglas de coordinación.

## Primera ejecución

Envíe este mensaje en el chat del proyecto:

> Inicia el sistema agéntico. Valida mi perfil, detecta las entradas pendientes, asigna el trabajo al Investigador y al Bibliotecario, y usa al Coordinador para consolidar los resultados en el dashboard. Antes de continuar, indícame si falta algún dato esencial de mi perfil.

Codex ejecutará los comandos locales necesarios. No hace falta abrir una terminal ni contratar una API adicional para esta modalidad de uso.

## Ejecuciones posteriores

Después de añadir nuevas noticias o documentos, envíe:

> Ejecuta una nueva actualización del sistema agéntico y muéstrame únicamente los cambios, alertas y decisiones pendientes.

Cuando el flujo manual esté comprobado, puede convertirse en una tarea programada desde las funciones disponibles en la aplicación.
