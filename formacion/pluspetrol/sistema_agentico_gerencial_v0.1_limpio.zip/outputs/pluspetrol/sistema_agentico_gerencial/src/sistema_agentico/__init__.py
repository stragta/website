"""Sistema agéntico gerencial para talleres."""

__version__ = "0.1.0"
