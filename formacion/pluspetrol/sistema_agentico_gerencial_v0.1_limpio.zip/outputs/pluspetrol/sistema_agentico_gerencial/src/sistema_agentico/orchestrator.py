from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any
from uuid import uuid4

from .io import read_json, relative_files, utc_now, write_json
from .project import Project
from .validation import validate_result


def _pending_files(
    current: list[dict[str, Any]], previous: dict[str, str]
) -> list[dict[str, Any]]:
    return [item for item in current if previous.get(item["archivo"]) != item["huella"]]


def build_plan(project: Project) -> dict[str, Any]:
    state = read_json(project.state_path, {"archivos_procesados": {}})
    processed = state.get("archivos_procesados", {})
    maximum = int(
        project.system().get("ejecucion", {}).get("maximo_elementos_por_agente", 100)
    )
    news = relative_files(project.root / "entrada" / "noticias", project.root)
    documents = relative_files(project.root / "entrada" / "documentos", project.root)
    pending_news = _pending_files(news, processed)[:maximum]
    pending_documents = _pending_files(documents, processed)[:maximum]
    run_id = f"run-{utc_now()[:10]}-{uuid4().hex[:8]}"
    plan = {
        "id": run_id,
        "creado": utc_now(),
        "perfil": project.profile(),
        "tareas": {
            "investigador": {
                "activa": bool(pending_news),
                "archivos": pending_news,
                "contrato": "agentes/investigador.md",
                "salida": "resultados/pendientes/investigador.json",
            },
            "bibliotecario": {
                "activa": bool(pending_documents),
                "archivos": pending_documents,
                "contrato": "agentes/bibliotecario.md",
                "salida": "resultados/pendientes/bibliotecario.json",
            },
        },
    }
    write_json(project.current_run_path, plan)
    return plan


def _deduplicate(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    output: list[dict[str, Any]] = []
    for record in records:
        identity = str(record.get("id") or record.get("url") or record.get("archivo") or "")
        if not identity or identity in seen:
            continue
        seen.add(identity)
        output.append(record)
    return output


def _merge_dataset(path: Path, new_records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    existing = read_json(path, [])
    records_by_id: dict[str, dict[str, Any]] = {}
    for record in [*existing, *new_records]:
        identity = str(record.get("id") or record.get("url") or record.get("archivo") or "")
        if identity:
            records_by_id[identity] = record
    merged = _deduplicate(list(records_by_id.values()))
    write_json(path, merged)
    return merged


def consolidate(project: Project) -> dict[str, Any]:
    plan = read_json(project.current_run_path)
    if not plan:
        raise RuntimeError("No existe un plan. Ejecute primero el comando plan.")

    result_paths = {
        "investigador": project.root / "resultados" / "pendientes" / "investigador.json",
        "bibliotecario": project.root / "resultados" / "pendientes" / "bibliotecario.json",
    }
    errors: list[str] = []
    results: dict[str, dict[str, Any]] = {}
    for agent, task in plan["tareas"].items():
        if not task["activa"]:
            continue
        agent_errors = validate_result(result_paths[agent], agent)
        errors.extend(agent_errors)
        if not agent_errors:
            results[agent] = read_json(result_paths[agent], {})
    if errors:
        raise ValueError("\n".join(errors))

    radar = _merge_dataset(
        project.root / "datos" / "radar.json",
        results.get("investigador", {}).get("registros", []),
    )
    library = _merge_dataset(
        project.root / "datos" / "biblioteca.json",
        results.get("bibliotecario", {}).get("registros", []),
    )

    warnings = []
    for result in results.values():
        warnings.extend(result.get("advertencias", []))

    activity = read_json(project.root / "datos" / "actividad.json", [])
    run_states = [result.get("estado") for result in results.values()]
    overall_state = (
        "completado"
        if all(state == "completado" for state in run_states)
        else "parcial"
    )
    activity.append(
        {
            "id": plan["id"],
            "fecha": utc_now(),
            "tipo": "ejecucion",
            "estado": overall_state,
            "agentes_ejecutados": sorted(results),
            "noticias_procesadas": len(results.get("investigador", {}).get("registros", [])),
            "documentos_procesados": len(results.get("bibliotecario", {}).get("registros", [])),
            "advertencias": warnings,
        }
    )
    write_json(project.root / "datos" / "actividad.json", activity)

    state = read_json(project.state_path, {"archivos_procesados": {}})
    processed = state.setdefault("archivos_procesados", {})
    for agent, task in plan["tareas"].items():
        if task["activa"] and results.get(agent, {}).get("estado") == "completado":
            for item in task["archivos"]:
                processed[item["archivo"]] = item["huella"]
    state["ultima_ejecucion"] = plan["id"]
    state["actualizado"] = utc_now()
    write_json(project.state_path, state)

    relevance = Counter(str(item.get("relevancia", "sin_clasificar")) for item in radar)
    dashboard = {
        "generado": utc_now(),
        "perfil": project.profile(),
        "resumen": {
            "noticias": len(radar),
            "documentos": len(library),
            "ejecuciones": len(activity),
            "pendientes_revision": len(warnings),
            "noticias_por_relevancia": dict(relevance),
        },
        "radar": radar,
        "biblioteca": library,
        "actividad": activity,
        "advertencias": warnings,
    }
    write_json(project.root / "dashboard" / "data.json", dashboard)

    history_path = project.root / "resultados" / "historial" / f"{plan['id']}.json"
    write_json(history_path, {"plan": plan, "resultados": results, "dashboard": dashboard})

    for path in result_paths.values():
        if path.exists():
            path.unlink()
    return dashboard


def project_status(project: Project) -> dict[str, Any]:
    state = read_json(project.state_path, {"archivos_procesados": {}})
    return {
        "proyecto": project.system().get("nombre_proyecto"),
        "perfil_configurado": all(
            bool(project.profile().get(field))
            for field in ("nombre", "cargo", "campo_interes")
        ),
        "entradas": {
            "noticias": len(relative_files(project.root / "entrada" / "noticias", project.root)),
            "documentos": len(relative_files(project.root / "entrada" / "documentos", project.root)),
        },
        "datos": {
            "radar": len(read_json(project.root / "datos" / "radar.json", [])),
            "biblioteca": len(read_json(project.root / "datos" / "biblioteca.json", [])),
            "actividad": len(read_json(project.root / "datos" / "actividad.json", [])),
        },
        "ultima_ejecucion": state.get("ultima_ejecucion"),
    }
