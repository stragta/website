from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .orchestrator import build_plan, consolidate, project_status
from .project import locate_project
from .validation import validate_project


def _print(payload: object) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def parser() -> argparse.ArgumentParser:
    command_parser = argparse.ArgumentParser(
        prog="taller-agentes",
        description="Administra el estado local del sistema agéntico gerencial.",
    )
    command_parser.add_argument(
        "--root", type=Path, help="Raíz del proyecto; por defecto se detecta automáticamente."
    )
    subcommands = command_parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("status", help="Muestra el estado actual del proyecto.")
    subcommands.add_parser("plan", help="Detecta entradas pendientes y crea un plan.")
    subcommands.add_parser("consolidate", help="Valida resultados y actualiza el dashboard.")
    subcommands.add_parser("validate", help="Valida configuración y estructura.")
    return command_parser


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        project = locate_project(args.root)
        if args.command == "status":
            _print(project_status(project))
        elif args.command == "plan":
            _print(build_plan(project))
        elif args.command == "consolidate":
            _print(consolidate(project)["resumen"])
        elif args.command == "validate":
            errors = validate_project(project)
            _print({"valido": not errors, "errores": errors})
            return 1 if errors else 0
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
