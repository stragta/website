from __future__ import annotations

from pathlib import Path
from typing import Any

from .io import read_json
from .project import Project


PROFILE_FIELDS = {
    "nombre": str,
    "cargo": str,
    "organizacion": str,
    "campo_interes": str,
    "temas_noticias": list,
    "tipos_documentos": list,
    "zona_horaria": str,
    "idioma": str,
}

RESULT_FIELDS = {"agente", "estado", "registros", "advertencias"}


def validate_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for field, expected_type in PROFILE_FIELDS.items():
        if field not in profile:
            errors.append(f"Falta el campo de perfil: {field}")
        elif not isinstance(profile[field], expected_type):
            errors.append(f"El campo {field} debe ser {expected_type.__name__}")
    for field in ("temas_noticias", "tipos_documentos"):
        values = profile.get(field, [])
        if isinstance(values, list) and not all(isinstance(item, str) for item in values):
            errors.append(f"Todos los valores de {field} deben ser texto")
    return errors


def validate_result(path: Path, expected_agent: str) -> list[str]:
    if not path.exists():
        return [f"No existe el resultado esperado: {path}"]
    try:
        payload = read_json(path, {})
    except Exception as exc:
        return [f"No se pudo leer {path}: {exc}"]
    if not isinstance(payload, dict):
        return [f"El resultado de {expected_agent} debe ser un objeto JSON"]
    errors = [
        f"Falta {field} en el resultado de {expected_agent}"
        for field in sorted(RESULT_FIELDS - payload.keys())
    ]
    if payload.get("agente") != expected_agent:
        errors.append(
            f"El resultado declara agente={payload.get('agente')!r}; se esperaba {expected_agent!r}"
        )
    if payload.get("estado") not in {"completado", "parcial", "bloqueado"}:
        errors.append(f"Estado inválido en el resultado de {expected_agent}")
    if not isinstance(payload.get("registros"), list):
        errors.append(f"registros debe ser una lista en {expected_agent}")
    if not isinstance(payload.get("advertencias"), list):
        errors.append(f"advertencias debe ser una lista en {expected_agent}")
    return errors


def validate_project(project: Project) -> list[str]:
    errors = validate_profile(project.profile())
    system = project.system()
    if not system.get("agentes"):
        errors.append("config/sistema.json no define agentes")
    required = [
        project.root / "agentes" / "investigador.md",
        project.root / "agentes" / "bibliotecario.md",
        project.root / "agentes" / "coordinador.md",
    ]
    for path in required:
        if not path.exists():
            errors.append(f"Falta el contrato: {path.relative_to(project.root)}")
    return errors
