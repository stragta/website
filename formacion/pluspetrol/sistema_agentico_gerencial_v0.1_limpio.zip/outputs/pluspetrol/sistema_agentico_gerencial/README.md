# Sistema agéntico gerencial

Base técnica del proyecto demostrativo para el taller. El sistema reúne tres responsabilidades dentro de un solo proyecto:

1. Investigador: procesa noticias y fuentes.
2. Bibliotecario: cataloga y resume documentos.
3. Coordinador: asigna el trabajo, valida resultados y actualiza los datos del dashboard.

La base limpia no contiene todavía noticias ni documentos sintéticos. Tampoco llama directamente a una API de modelos. Codex aporta la ejecución agéntica; este proyecto aporta estructura, estado, contratos de datos y trazabilidad.

## Dos rutas para el taller

- **Construcción desde cero:** siga `GUIA_CONSTRUCCION_DESDE_CERO.md` para crear la carpeta, los contratos, el motor local y el dashboard paso a paso.
- **Inicio rápido:** siga `INICIAR_EN_CODEX.md` para abrir la base descargable, completar el perfil y ejecutar el flujo ya preparado.

Ambas rutas terminan en la misma arquitectura: Investigador, Bibliotecario y Coordinador dentro de un solo proyecto.

La interfaz visual está en `dashboard/index.html` y lee `dashboard/data.json`, que actualiza el Coordinador. Para verla localmente, siga las instrucciones de `dashboard/README.md`.

## Comandos de desarrollo

Desde la raíz del proyecto:

```bash
PYTHONPATH=src python3 -m sistema_agentico status
PYTHONPATH=src python3 -m sistema_agentico plan
PYTHONPATH=src python3 -m sistema_agentico consolidate
PYTHONPATH=src python3 -m sistema_agentico validate
```

Los datos sintéticos de demostración se incorporarán en una versión posterior del paquete, sin mezclarlos con datos institucionales reales.
