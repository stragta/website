# Dashboard

`index.html` es la interfaz visual. `data.json` es la fuente de datos que actualiza el Coordinador.

Para probarlo localmente desde la raíz del proyecto:

```bash
python3 -m http.server 8000 --directory dashboard
```

Después abre `http://localhost:8000`. Servir la carpeta es necesario porque el navegador puede bloquear la lectura de `data.json` cuando se abre el HTML directamente como `file://`.
